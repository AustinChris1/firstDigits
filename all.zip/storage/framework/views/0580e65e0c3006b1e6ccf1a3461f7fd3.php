<!DOCTYPE html>
<html>
<head>
    <title>Verify Your Email Address</title>
</head>
<body>
    <h1>Hi there!</h1>
<p>Didn't get the email?</p>    
<form method="POST" action="<?php echo e(route('verification.send')); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit" style="display: inline-block; padding: 10px 20px; color: white; background-color: blue; text-decoration: none; border-radius: 5px;">
        Resend Email
    </button>
</body>
</html>
<?php /**PATH C:\Users\Admin\Desktop\ok\resources\views\auth\verify-email.blade.php ENDPATH**/ ?>