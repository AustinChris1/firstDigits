import React, { useEffect, useState, useCallback } from "react";
import { Clock, Share2, ArrowUp } from "lucide-react";
import { Link } from "react-router-dom";
import swal from "sweetalert";

const Sidebar = () => {
    const [history, setHistory] = useState([]);
    const [showTooltip, setShowTooltip] = useState(false); // State to control tooltip visibility

    useEffect(() => {
        const pageTitle = document.title;
        const pageUrl = window.location.href;
    
        // Fetch existing visited pages or initialize as empty
        const visitedPages =
          JSON.parse(localStorage.getItem("visitedPages")) || [];
        const currentPage = { title: pageTitle, url: pageUrl };
    
        // Ensure only pages from the current domain are included
        const domain = window.location.origin;
        const filteredPages = visitedPages.filter((page) =>
          page.url.startsWith(domain)
        );
    
        // Prevent duplicates for the same page URL
        if (!filteredPages.some((page) => page.url === pageUrl)) {
          filteredPages.push(currentPage);
          localStorage.setItem("visitedPages", JSON.stringify(filteredPages));
        }
    
        // Update the history state with the last 5 pages
        setHistory(filteredPages.slice(-5));
      }, []);
    
      const handleRecentlyViewedClick = () => {
        // console.log("Recently Viewed Pages:", history);
        setShowTooltip((prev) => !prev); // Toggle tooltip visibility on button click
      };
    
    
    // Scroll to the top of the page
    const handleScrollToTop = () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    };

    // Handle sharing the current page using the Web Share API
    const handleShare = async () => {
        if (navigator.share) {
            try {
                await navigator.share({
                    title: document.title,
                    url: window.location.href,
                });
            } catch (error) {
                console.error("Error sharing page:", error);
            }
        } else {
            console.warn("Share API is not supported on this browser.");
        }
    };

    // Close tooltip when clicking outside of it
    const handleClickOutside = useCallback((event) => {
        if (showTooltip && !event.target.closest(".tooltip-container") && !event.target.closest(".recently-viewed-btn")) {
            setShowTooltip(false); // Close the tooltip if clicked outside
        }
    }, [showTooltip]);

    useEffect(() => {
        document.addEventListener("click", handleClickOutside);
        return () => document.removeEventListener("click", handleClickOutside);
    }, [handleClickOutside]);

    return (
        <div className="fixed top-1/3 z-20 right-4 flex flex-col items-center space-y-2">
            {/* Recently Viewed Button */}
            <div className="relative">
                <button
                    onClick={handleRecentlyViewedClick}
                    className="recently-viewed-btn bg-gray-200 text-gray-700 rounded-full p-2 shadow hover:bg-gray-300"
                    title="Recently Viewed"
                >
                    <Clock size={20} />
                </button>

                {/* Tooltip showing recently viewed pages */}
                {showTooltip && (
                    <div className="tooltip-container absolute right-full top-1/2 transform translate-x-2 -translate-y-1/2 bg-white border border-gray-300 text-gray-800 rounded-md shadow-md p-3 text-sm flex flex-col w-48 z-20">
                        <p className="font-bold mb-2">Recently Viewed:</p>
                        <ul className="space-y-1">
                            {history.length > 0 ? (
                                history
                                    .reverse() // Reverse to show the most recent first
                                    .map((page, index) => (
                                        <li key={index}>
                                            <Link
                                                to={page.url}
                                                className="text-blue-500 hover:underline"
                                                title={page.title}
                                            >
                                                {page.title}
                                            </Link>
                                        </li>
                                    ))
                            ) : (
                                <li className="text-gray-500">No recently viewed pages.</li>
                            )}
                        </ul>
                    </div>
                )}
            </div>

            {/* Share Button */}
            <button
                onClick={handleShare}
                className="bg-gray-200 text-gray-700 rounded-full p-2 shadow hover:bg-gray-300"
                title="Share Page"
            >
                <Share2 size={20} />
            </button>

            {/* Scroll to Top Button */}
            <button
                onClick={handleScrollToTop}
                className="bg-gray-200 text-gray-700 rounded-full p-2 shadow hover:bg-gray-300"
                title="Scroll to Top"
            >
                <ArrowUp size={20} />
            </button>
        </div>
    );
};

export default Sidebar;
