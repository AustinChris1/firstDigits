import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import axios from 'axios';

// Importing layouts and components
import Master from './layouts/admin/Master';
import Register from './layouts/frontend/auth/Register';
import Login from './layouts/frontend/auth/Login';
import AdminPrivateRoute from './AdminPrivateRoute';
import Navbar from './layouts/frontend/Components/Navbar';
import Slider from './layouts/frontend/Components/Slider';
import About from './layouts/frontend/Components/About';
import Products from './layouts/frontend/Components/Products';
import Partners from './layouts/frontend/Components/Partners';
import Footer from './layouts/frontend/Components/Footer';
import Store from './layouts/frontend/Outer/Store';
import ProductDetail from './layouts/frontend/Outer/Detail';
import NotFound from './layouts/frontend/Components/404';
import Forbidden from './layouts/frontend/Components/403';
import ScrollToTop from './layouts/frontend/Components/ScrollToTop';

// Axios configuration
axios.defaults.withCredentials = true;
axios.defaults.baseURL = '/';
axios.defaults.headers.post['Content-Type'] = 'application/json';
axios.defaults.headers.post['Accept'] = 'application/json';

// Interceptor for adding Authorization header
axios.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Home component
function Home() {
  return (
    <>
      <Slider />
      <About />
      <Products />
      <Partners />
    </>
  );
}

// Layout component
function Layout() {
  const location = useLocation();
  const isAdminRoute = location.pathname.startsWith('/admin');

  // Protected route for redirecting authenticated users from login/register pages
  const ProtectedRoute = ({ element }) => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      return <Navigate to="/" replace />;
    }
    return element;
  };

  return (
    <>
      {!isAdminRoute && <Navbar />}
      <Routes>
        {/* Admin routes protected with AdminPrivateRoute */}
        <Route
          path="/admin/*"
          element={
            <AdminPrivateRoute>
              <Master />
            </AdminPrivateRoute>
          }
        />
        
        {/* Frontend routes */}
        <Route path="/" element={<Home />} />
        <Route path="/store" element={<Store />} />
        <Route path="/collections/:categoryLink/:productLink" element={<ProductDetail />} />
        <Route path="/404" element={<NotFound />} />
        <Route path="/403" element={<Forbidden />} />
        <Route path="/login" element={<ProtectedRoute element={<Login />} />} />
        <Route path="/register" element={<ProtectedRoute element={<Register />} />} />
      </Routes>
      {!isAdminRoute && <Footer />}
    </>
  );
}

// Main App component
function App() {
  // Fetch the CSRF token cookie upon app load
  useEffect(() => {
    axios.get('/sanctum/csrf-cookie')
      .then(() => console.log('CSRF token fetched and ready for use'))
      .catch(error => console.error('Failed to fetch CSRF token:', error));
  }, []);

  return (
    <div className="App font-raleway">
      <Router>
        <ScrollToTop />
        <Layout />
      </Router>
    </div>
  );
}

export default App;
